<div id="tve-tab_image-component" class="tve-component" data-view="TabImage">
	<div class="dropdown-header" data-prop="docked">
		<?php echo esc_html__( 'Main Options', 'thrive-cb' ); ?>
		<i></i>
	</div>
	<div class="dropdown-content">
		<div class="hide-tablet hide-mobile">
			<div class="tve-control" data-view="ImagePicker"></div>
			<hr>
		</div>
		<div class="tve-control" data-view="Height"></div>
	</div>
</div>
