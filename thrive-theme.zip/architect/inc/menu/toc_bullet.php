<div id="tve-toc_bullet-component" class="tve-component" data-view="TOCBullet">
	<div class="dropdown-header" data-prop="docked">
		<div class="group-description"><?php echo esc_html__( 'Main Options', 'thrive-cb' ); ?></div>
		<i></i>
	</div>
	<div class="dropdown-content">
		<div class="hide-states pb-10">
			<div class="tve-control tve-choose-icon gl-st-icon-toggle-2" data-view="ModalPicker"></div>
		</div>
		<div class="tve-control no-space gl-st-icon-toggle-1" data-view="ColorPicker"></div>
		<div class="hide-states pt-10">
			<div class="tve-control gl-st-icon-toggle-1" data-view="Slider"></div>
		</div>
	</div>
</div>
