<a href="javascript:void(0);" class="click lp-category" data-fn="filter" data-source="category" data-item="<#= id #>">
	<span><#= name #></span>
	<span><#= counter #></span>
</a>
